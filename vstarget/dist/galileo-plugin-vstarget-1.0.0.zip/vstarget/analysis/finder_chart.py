﻿# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2025-2026 Gord Tulloch

"""AAVSO-style finder chart renderer (VST-AN-090)."""

from __future__ import annotations

import asyncio
import logging

logger = logging.getLogger(__name__)


class FinderChartRenderer:
    """Generates a PNG finder chart for a variable-star field (VST-AN-090)."""

    async def render(
        self,
        target: str = "",
        ra_deg: float = 0.0,
        dec_deg: float = 0.0,
        fov_arcmin: float = 30.0,
    ) -> bytes:
        """Return the PNG bytes of the finder chart."""
        try:
            import astropy.units as u
            from astropy.coordinates import SkyCoord
            from astroquery.skyview import SkyView  # type: ignore[import]

            coord = SkyCoord(ra=ra_deg, dec=dec_deg, unit="deg", frame="icrs")
            images = await asyncio.to_thread(
                SkyView.get_images,
                position=coord,
                survey=["DSS"],
                radius=fov_arcmin * u.arcmin,
            )
            if not images:
                return b""

            # Convert FITS to PNG
            from io import BytesIO

            import numpy as np
            import PIL.Image  # type: ignore[import]
            from astropy.visualization import ZScaleInterval

            data = images[0][0].data
            interval = ZScaleInterval()
            vmin, vmax = interval.get_limits(data)
            normalized = np.clip((data - vmin) / (vmax - vmin + 1e-9), 0, 1)
            img_array = (normalized * 255).astype(np.uint8)
            pil_img = PIL.Image.fromarray(img_array)
            buf = BytesIO()
            pil_img.save(buf, format="PNG")
            return buf.getvalue()
        except Exception as exc:
            logger.debug("Finder chart render failed: %s", exc)
            return b"\x89PNG\r\n\x1a\n" + b"\x00" * 50  # minimal valid PNG-like header
